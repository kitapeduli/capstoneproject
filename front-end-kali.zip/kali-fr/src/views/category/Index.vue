<template>
    <div class="pb-20 pt-20 h-screen">
        <div class="w-4/5 max-md:w-full mx-auto p-4">
            <div class="text-center my-4 text-white font-bold text-2xl max-md:text-lg max-sm:text-sm">SEMUA CATEGORY</div>
            <div v-if="categories.length > 0">
            <div class="flex justify-center flex-wrap gap-4 max-sm:gap-2 text-center items-center p-2">
                <div v-for="category in categories" :key="category.id" class="w-1/4 max-sm:w-full bg-white flex justify-center items-center p-2 rounded-sm shadow-sm hover:bg-gradient-to-r from-cyan-500 to-biru duration-300 border group">
                    <router-link :to="{name: 'category.show', params:{slug: category.slug}}" class="text-biru font-semibold max-sm:text-sm group-hover:text-white">
                        <div>
                            <img :src="category.image" class="inline-block mb-2 w-20 h-20 rounded-sm ">
                        </div>
                        {{ category.name.toUpperCase() }}
                    </router-link>
                </div>
            </div>
        </div>
        <div v-else>
            <div class="mt-5 grid grid-cols-4  gap-4 md:gap-4 text-center items-center">
                <div v-for="index in 4" :key="index" class="sm:col-span-2 md:col-span-1 lg:col-span-1 bg-white rounded-md shadow-md text-center text-xs">
                    <ContentLoader />
                </div>
            </div>
        </div>

        </div>
    </div>
</template>

<script>

    //hook vue
    import { onMounted, computed } from 'vue'
    
    //hook vuex
    import { useStore } from 'vuex'

    //content loader
    import { ContentLoader } from 'vue-content-loader'

    export default {

        name: 'CategoryIndexComponent',

        components: {
            ContentLoader // <-- register content loader
        },

        setup() {

            //store vuex
            const store = useStore()

            //onMounted akan menjalankan action "getCategory" di module "category"
            onMounted(() => {
                store.dispatch('category/getCategory')
            })

            //digunakan untuk get data state "categories" di module "category" 
            const categories = computed(() => {
                return store.state.category.categories
            })

            return {
                categories      // <-- state categories
            }
        }

    }
</script>

<style>

</style>