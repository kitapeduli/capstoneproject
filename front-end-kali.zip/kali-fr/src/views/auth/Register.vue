<template>
    <div class="pb-20 pt-20 mt-20 max-md:mt-10 h-screen flex justify-center items-center">
        <div class="container mx-auto grid grid-cols-1 p-5 sm:w-full md:w-5/12">

            <form @submit.prevent="register">
                <div class="bg-white rounded-md shadow-md p-5">
                    <div class="text-xl text-center text-biru font-semibold">
                        BUAT AKUN
                    </div>
                    <div class="border border-blue-100 mt-3 mb-2"></div>


                    <div class="mb-2">
                        <label class="mt-2 font-medium text-biru">Nama Lengkap</label>
                        <input type="text" v-model="user.name"
                            class="mt-2 appearance-none w-full border bg-blue-100 border-blue-100 rounded h-7 placeholder-black focus:outline-none focus:placeholder-biru focus:bg-white focus:shadow-lg focus:border-none focus-within:text-biru p-5 duration-300"
                            placeholder="Nama Lengkap">
                    </div>

                    <div class="mb-2">
                        <label class="mt-2 font-medium text-biru">Alamat Email</label>
                        <input type="email" v-model="user.email"
                            class="mt-2 appearance-none w-full border bg-blue-100 border-blue-100 rounded h-7 placeholder-black focus:outline-none focus:placeholder-biru focus:bg-white focus:shadow-lg focus:border-none focus-within:text-biru p-5 duration-300"
                            placeholder="Alamat Email">
                    </div>

                    <div class="cols-span-1 mb-5">
                        <label class="mt-2 font-medium text-biru">Password</label>
                        <input type="password" v-model="user.password"
                            class="mt-2 appearance-none w-full border bg-blue-100 border-blue-100 rounded h-7 placeholder-black focus:outline-none focus:placeholder-biru focus:bg-white focus:shadow-lg focus:border-none focus-within:text-biru p-5 duration-300"
                            placeholder="Password">
                    </div>

                    <div class="cols-span-1 mb-5">
                        <label class="mt-2 font-medium text-biru">Konfirmasi Password</label>
                        <input type="password" v-model="user.password_confirmation"
                            class="mt-2 appearance-none w-full border bg-blue-100 border-blue-100 rounded h-7 placeholder-black focus:outline-none focus:placeholder-biru focus:bg-white focus:shadow-lg focus:border-none focus-within:text-biru p-5 duration-300"
                            placeholder="Konfirmasi Password">
                    </div>

                    <div>
                        <button
                            class="bg-gradient-to-r from-cyan-500 to-biru relative py-1 px-3 text-white rounded-md shadow-md text-xl inline-block w-full focus:outline-none hover:bg-gray-900 duration-300 focus:bg-gray-900">DAFTAR</button>
                    </div>

                </div>
            </form>

            <div class="text-center mt-5 text-white">
                Sudah punya akun ? <router-link :to="{name: 'login'}" class="underline text-white">Masuk Disini
                    !</router-link>
            </div>

        </div>
    </div>
</template>

<script>

    //hook vue
    import { ref, reactive } from 'vue'
    
    //hook vuex
    import { useStore } from 'vuex'
    
    //hook vue router
    import { useRouter } from 'vue-router'
    
    //hook Toast
    import { useToast } from "vue-toastification"

    export default {

        name: 'RegisterComponent',

        setup() {

            //user state
            const user = reactive({
                name: '',
                email: '',
                password: '',
                password_confirmation: ''
            })

            //validation state
            const validation = ref([])

            //store vuex
            const store = useStore()

            //route
            const router = useRouter()

            //same interface as this.$toast
            const toast = useToast()

            //function register, fungsi ini di jalankan ketika form di submit
            function register() {

                //define variable 
                let name     = user.name
                let email    = user.email
                let password = user.password
                let password_confirmation = user.password_confirmation

               //panggil actions "register" dari module "auth"
                store.dispatch('auth/register', {
                    name,
                    email,
                    password,
                    password_confirmation
                })
                .then(() => {

                    //redirect ke dashboard
                    router.push({name: 'dashboard'})

                    toast.success("Register Berhasil!")

                }).catch(error => {
                    //show validaation message
                    validation.value = error

                    //show validation name with toast
                    if(validation.value.name) {
                        toast.error(`${validation.value.name[0]}`)
                    }

                    //show validation email with toast
                    if(validation.value.email) {
                        toast.error(`${validation.value.email[0]}`)
                    }

                    //show validation password with toast
                    if(validation.value.password) {
                        toast.error(`${validation.value.password[0]}`)
                    }
                })
            }

            //return a state and function
            return {
                user,           // <-- state user
                validation,     // <-- state validation
                register,       // <-- method register
                toast           // <-- hook toast
            }

        }

    }
</script>

<style>

</style>