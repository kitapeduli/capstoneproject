<template>
    <div class="pb-20 pt-20">
        <div class="w-10/12 m-auto max-md:w-11/12">

            <div v-if="campaigns.length > 0" class="flex justify-center flex-wrap max-md:flex-col w-full gap-4">
                <div class="rounded-md bg-white cursor-pointer shadow-md p-2 duration-300  hover:scale-105 w-1/4 max-lg:w-4/12 max-md:w-full"
                    v-for="campaign in campaigns" :key="campaign.id">
                    <div class="w-full m-auto">
                        <!-- card -->
                        <div class="bg-white">
                            <div class="flex flex-col">
                                <img class="block w-full m-auto h-full object-cover" :src="campaign.image" width="384"
                                    height="512">
                                <div class="w-full pt-6 p-5 md:p-3 text-center md:text-left space-y-4">
                                    <router-link :to="{ name: 'campaign.show', params: { slug: campaign.slug } }">
                                        <p class="text-center text-biru font-semibold hover:text-blue-300">
                                            {{ campaign.title }}
                                        </p>
                                    </router-link>
                                    <div class="font-medium">
                                        <div class="mt-3 text-blue-400 text-xs">
                                            {{ campaign.user.name }}
                                        </div>
                                        <div v-if="campaign.sum_donation.length > 0">
                                            <div v-for="donation in campaign.sum_donation" :key="donation">

                                                <div class="relative pt-1">
                                                    <div
                                                        class="overflow-hidden h-2 mb-4 text-xs flex rounded bg-blue-200">
                                                        <div :style="{ width: percentage(donation.total, campaign.target_donation) + '%' }"
                                                            class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-500">
                                                        </div>
                                                    </div>
                                                </div>

                                                <p class="text-xs text-gray-500">
                                                    <span class="font-bold text-yellow-500">Rp. {{
                                                        formatPrice(donation.total) }} </span> terkumpul dari
                                                    <span class="font-bold text-green-700">Rp. {{
                                                        formatPrice(campaign.target_donation) }}</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div v-else>

                                            <div class="relative pt-1">
                                                <div class="overflow-hidden h-2 mb-4 text-xs flex rounded bg-blue-200">
                                                    <div :style="{ width: percentage(0, campaign.target_donation) + '%' }"
                                                        class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-500">
                                                    </div>
                                                </div>
                                            </div>

                                            <p class="text-xs text-gray-500">
                                                <span class="font-bold text-yellow-400">Rp. 0 </span> terkumpul dari
                                                <span class="font-bold text-green-700">Rp. {{
                                                    formatPrice(campaign.target_donation) }}</span>
                                            </p>
                                        </div>
                                        <div class="mt-3 text-xs text-biru">
                                            <strong>{{ countDay(campaign.max_date) }}</strong> hari lagi
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div v-else class="flex flex-wrap gap-4 justify-center">

                <div v-for="index in 6" :key="index"
                    class="bg-white flex justify-center w-1/4 rounded shadow-md p-3 text-sm text-center">
                    <FacebookLoader class="h-60" />
                </div>

            </div>

        </div>

        <div class="text-center mt-4 mb-4" v-show="nextExists">
            <a @click="loadMore"
                class="text-white p-2 px-3 rounded-md hover:underline focus:outline-none focus:bg-gray-900 cursor-pointer">LIHAT
                SEMUA <i class="fa fa-long-arrow-alt-right"></i></a>
        </div>

    </div>
</template>

<script>

//hook vue
import { computed, onMounted } from 'vue'

//vuex
import { useStore } from 'vuex'

//vue content loader
import { FacebookLoader } from 'vue-content-loader'

export default {

    name: 'CampaignIndexComponent',

    components: {
        FacebookLoader  // <-- register component FacebooLoader dari Vue Content Loader
    },

    setup() {

        //store vuex
        const store = useStore()

        //onMounted akan menjalankan action "getCampaign" di module "campaign"
        onMounted(() => {
            store.dispatch('campaign/getCampaign')
        })

        //digunakan untuk get data  state "campaigns" di module "campaign" 
        const campaigns = computed(() => {
            return store.state.campaign.campaigns
        })

        //get status NextExists
        const nextExists = computed(() => {
            return store.state.campaign.nextExists
        })

        //get nextPage
        const nextPage = computed(() => {
            return store.state.campaign.nextPage
        })

        //loadMore function
        function loadMore() {
            store.dispatch('campaign/getLoadMore', nextPage.value)
        }

        return {
            campaigns,      // <-- return campaigns
            nextExists,     // <-- return nextExists,
            nextPage,       // <-- return nextPage
            loadMore,        // <-- return loadMore
        }

    }

}
</script>

<style></style>