<template>
    <div class="pb-20 pt-20">
        <div class="container mx-auto grid grid-cols-1 p-3 sm:w-full md:w-5/12">

            <div class="bg-gradient-to-r from-cyan-500 to-biru border rounded-md shadow-md p-5">
                <div class="text-xl text-white font-semibold">
                    Masukkan nominal
                </div>
                <div class="border-2 border-white mt-3 mb-2"></div>

                <div class="mb-2">
                    <label class="mt-2 font-bold text-lg text-white">Rp.</label>
                    <input type="number"
                        class="mt-2 appearance-none w-full bg-white border border-gray-200 rounded h-15 shadow-sm placeholder-gray-600 focus:outline-none focus:placeholder-gray-600 focus:bg-white focus-within:text-gray-600 p-2 text-right text-xl"
                        placeholder="0" v-model="donation.amount">
                </div>

                <div class="mb-2">
                    <label class="mt-2 font-bold text-lg text-white">Pesan</label>
                    <textarea rows="3" v-model="donation.pray"
                        class="mt-2 appearance-none w-full bg-white border border-gray-200 rounded shadow-sm placeholder-gray-600 focus:outline-none focus:placeholder-gray-600 focus:bg-white focus-within:text-gray-600 p-5" placeholder="pesan yang ingin di sampaikan💖">
                    </textarea>
                </div>

                <button @click="storeDonation" class="mt-4 bg-white text-biru py-2 rounded-md shadow-md text-base w-full uppercase font-bold focus:outline-none focus:bg-yellow-600">LANJUTKAN PEMBAYARAN</button>

            </div>

        </div>
    </div>
</template>

<script>

    //hook vue
    import { reactive } from 'vue'
    
    //hook vuex
    import { useStore } from 'vuex'
    
    //hook vue router
    import { useRoute, useRouter } from 'vue-router'
    
    //hook Toast
    import { useToast } from "vue-toastification"

    export default {

        name: 'DonationCreateComponent',

        setup() {

            //store vuex
            const store = useStore()

            //route
            const route = useRoute()

            //router
            const router = useRouter()

            //toast
            const toast = useToast()

            //state donation
            const donation = reactive({
                amount: 0,                      // <-- data nilai donasi
                pray: '',                       // <-- data kata-kata/doa
                campaignSlug: route.params.slug // <-- data "slug" dari campaign
            })

            //method store donation
            function storeDonation() {

                //check minimal donasi
                if(donation.amount < 10000) {
                    toast.error('Donasi Minimal Rp. 10.000')
                    return false
                }

                store.dispatch('donation/storeDonation', donation)
                .then(() => {

                    toast.success('Transaksi Berhasil, terimakasih orang baik 💖')

                    //redirect ke dashboard
                    router.push({name: 'donation.index'})

                })
                .catch(error => {
                    console.log(error)
                })
            }

            return {
                donation,       // <-- state donation
                storeDonation   // <-- method storeDonation
            }

        }

    }
</script>

<style>

</style>