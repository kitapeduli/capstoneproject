<template>

    <div class="">
        <!-- hero -->
        <div class="hero bg-heroo bg-cover bg-no-repeat h-screen backdrop-opacity-40 z-30 ">
            <div class="absolute left-0 right-0 top-0 bottom-0 bg-heroc"></div>
            <div class="relative z-20 flex flex-col items-center justify-center w-full h-screen">
                <h1 class="text-4xl text-white p-3 max-md:p-2 font-bold max-lg:text-2xl max-sm:text-xl text-center">Kita
                    Peduli,Kita Memberi, Kita Beraksi!</h1>
                <p class="w-2/5 max-md:w-3/4 max-lg:w-3/5 max-md:text-lg max-sm:text-sm text-center text-white font-medium pb-4">
                    "Bukankah kebahagiaan datang dari memberi. Mari ulurkan tangan, sebarkan kasih.Bersama kita ciptakan
                    dunia yang lebih baik,Penuh cinta dan kebahagiaan yang tak terputus."</p>
                <a href="#sldr"
                    class="bg-gradient-to-r from-cyan-500 to-biru text-white flex justify-center items-center h-11 w-32 max-lg:h-11 max-lg:w-32 max-md:w-32 max-md:h-11 max-sm:w-20 max-sm:h-9 max-sm:text-xs rounded-md text-lg max-lg:text-sm">Kita
                    Peduli</a>
                
            </div>
        </div>
        <!-- container -->
        <div id="sldr"></div>
        <div class="w-11/12 mx-auto max-md:w-11/12 mt-20">

            <!-- slider -->
            <div class="grid grid-cols-1 bg-white rounded shadow-md p-1 text-sm">
                <Slider />
            </div>

            <!-- categoryHome -->
            <div class="w-full my-11">
                <CategoryHome />
            </div>
            <div v-if="campaigns.length > 0" class="flex justify-center flex-wrap max-md:flex-col w-full gap-4">

                <div class="rounded-md bg-white cursor-pointer shadow-md p-2 duration-300  hover:scale-105 w-1/4 max-lg:w-4/12 max-md:w-full  "
                    v-for="campaign in campaigns" :key="campaign.id">
                    <div class="w-full m-auto">
                        <!-- card -->
                        <div class="bg-white">
                            <div class="">
                                <img class="block w-full m-auto h-full object-cover" :src="campaign.image">
                                <div class="py-4 text-center">
                                    <router-link :to="{ name: 'campaign.show', params: { slug: campaign.slug } }">
                                        <p class="text-sm font-bold text-biru  hover:text-blue-300">
                                            {{ campaign.title }}
                                        </p>
                                    </router-link>
                                    <div class="font-medium text-left">
                                        <div class="mt-3 text-blue-400 text-xs">
                                            {{ campaign.user.name }}
                                        </div>
                                        <div v-if="campaign.sum_donation.length > 0">
                                            <div v-for="donation in campaign.sum_donation" :key="donation">

                                                <div class="relative pt-1">
                                                    <div
                                                        class="overflow-hidden h-2 mb-4 text-xs flex rounded bg-blue-200">
                                                        <div :style="{ width: percentage(donation.total, campaign.target_donation) + '%' }"
                                                            class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-500">
                                                        </div>
                                                    </div>
                                                </div>

                                                <p class="text-xs text-gray-500">
                                                    <span class="font-bold text-blue-400">Rp. {{
                                                        formatPrice(donation.total) }} </span> terkumpul dari
                                                    <span class="font-bold">Rp. {{ formatPrice(campaign.target_donation)
                                                        }}</span>
                                                </p>
                                            </div>
                                        </div>
                                        <div v-else>

                                            <div class="relative pt-1">
                                                <div class="overflow-hidden h-2 mb-4 text-xs flex rounded bg-blue-300">
                                                    <div :style="{ width: percentage(0, campaign.target_donation) + '%' }"
                                                        class="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-blue-500">
                                                    </div>
                                                </div>
                                            </div>

                                            <p class="text-xs text-gray-500">
                                                <span class="font-bold text-yellow-400">Rp. 0 </span> terkumpul dari
                                                <span class="font-bold text-green-700">Rp. {{
                                                    formatPrice(campaign.target_donation)
                                                    }}</span>
                                            </p>
                                        </div>
                                        <div class="mt-3 text-xs text-biru">tersisa
                                            <strong>{{ countDay(campaign.max_date) }}</strong> hari lagi
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div v-else class="flex flex-wrap gap-4 justify-center">

                <div v-for="index in 6" :key="index"
                    class="bg-white flex justify-center w-1/4 rounded shadow-md p-3 text-sm text-center">
                    <FacebookLoader class="h-60" />
                </div>

            </div>

        </div>

        <div class="text-center mt-4 mb-4" v-show="nextExists">
            <a @click="loadMore"
                class=" text-white p-2 px-3 rounded-md hover:underline focus:outline-none focus:bg-gray-900 cursor-pointer">TAMPILKAN
                SEMUA <i class="fa fa-long-arrow-alt-right"></i></a>
        </div>

    </div>
</template>

<script>

//hook vue
import { computed, onMounted } from 'vue'

//vuex
import { useStore } from 'vuex'

//component slider
import Slider from '../../components/Slider.vue'

//component categoryHome
import CategoryHome from '../../components/CategoryHome.vue'

//vue content loader
import { FacebookLoader } from 'vue-content-loader'

export default {

    name: 'HomeComponent',

    components: {
        Slider,         // <-- register component slider
        CategoryHome,   // <-- register component CategoryHome
        FacebookLoader  // <-- register component FacebooLoader dari Vue Content Loader
    },

    setup() {

        //store vuex
        const store = useStore()

        //onMounted akan menjalankan action "getCampaign" di module "campaign"
        onMounted(() => {
            store.dispatch('campaign/getCampaign')
        })

        //digunakan untuk get data  state "campaigns" di module "campaign" 
        const campaigns = computed(() => {
            return store.state.campaign.campaigns
        })

        /**
         * LOADMORE
         */

        //get status NextExists
        const nextExists = computed(() => {
            return store.state.campaign.nextExists
        })

        //get nextPage
        const nextPage = computed(() => {
            return store.state.campaign.nextPage
        })

        //loadMore function
        function loadMore() {
            store.dispatch('campaign/getLoadMore', nextPage.value)
        }

        return {
            campaigns,      // <-- return campaigns
            nextExists,     // <-- return nextExists,
            nextPage,       // <-- return nextPage
            loadMore,        // <-- return loadMore
        }

    }

}
</script>
