<template>
    <div class="pt-24 w-10/12 m-auto relative">
        <!-- kali1 -->
         <div class="text-center text-white text-2xl max-md:text-lg uppercase font-semibold mb-20">tentang kali</div>
        <div class="flex justify-center  items-center group max-sm:flex-col">
            <img src="../../assets/images/kali1.jpeg" alt=""
                class="w-1/3 rounded-sm hover:shadow-sm ml-10 max-md:ml-0 group-hover:bg-white p-4 duration-300 max-md:w-full ">
            <div
                class="text-biru bg-white p-4 relative right-10 max-sm:right-0 rounded-sm text-lg group-hover:scale-105 duration-300 max-md:-top-40">
                <h3 class="font-bold text-2xl max-md:text-lg">Selamat Datang di KALI</h3>
                <P class="max-md:text-sm">
                    Sebuah platform donasi inovatif yang dirancang untuk mengatasi tantangan sosial yang semakin
                    kompleks di sekitar kita. Di tengah berbagai masalah seperti bencana alam, kecelakaan, dan kesulitan
                    ekonomi, kepedulian sosial menjadi sangat penting. Namun, seringkali sulit untuk mewujudkan
                    kepedulian ini dalam tindakan nyata. KALI hadir untuk menjembatani kesenjangan ini, memberikan
                    solusi yang mudah, aman, dan transparan bagi mereka yang ingin berkontribusi.</P>
            </div>
        </div>
        <div class="border-2 rounded-sm border-white w-full"></div>
        <!-- kali2 -->
        <div class="flex justify-center  items-center group max-sm:flex-col mt-20 mb-20">
            <div
                class="text-biru bg-white p-4 relative left-10 max-sm:left-0 rounded-sm text-lg group-hover:scale-105 duration-300 max-md:-top-40">
                <h3 class="font-bold text-2xl max-md:text-lg">Mengapa KALI Hadir?</h3>
                <P class="max-md:text-sm">
                    Kehadiran KALI didorong oleh kebutuhan akan sebuah platform yang menyederhanakan proses donasi. Kami
                    memahami bahwa banyak orang yang ingin membantu, namun mereka seringkali ragu karena kekhawatiran
                    mengenai transparansi dan efektivitas penggunaan dana. KALI bertujuan untuk mengatasi kekhawatiran
                    ini dengan menyediakan informasi yang jelas dan transparan tentang tujuan donasi serta memastikan
                    bahwa setiap sumbangan digunakan sesuai dengan tujuannya. </P>
            </div>
            <img src="../../assets/images/kali2.jpg" alt=""
                class="w-1/3 rounded-sm hover:shadow-sm mr-10 max-md:mr-0 group-hover:bg-white p-4 duration-300 max-md:w-full ">
        </div>
        <div class="border-2 rounded-sm border-white w-full mb-20"></div>
        <!-- kali3 -->
        <div class="flex justify-center  items-center group max-sm:flex-col">
            <img src="../../assets/images/kali3.jpeg" alt=""
                class="w-1/3 rounded-sm hover:shadow-sm ml-10 max-md:ml-0 group-hover:bg-white p-4 duration-300 max-md:w-full ">
            <div
                class="text-biru bg-white p-4 relative right-10 max-sm:right-0 rounded-sm text-lg group-hover:scale-105 duration-300 max-md:-top-40">
                <h3 class="font-bold text-2xl max-md:text-lg">Visi KALI</h3>
                <P class="max-md:text-sm">

                    Menjadi platform donasi terdepan yang menginspirasi dan memfasilitasi perubahan positif di
                    masyarakat melalui transparansi, kepercayaan, dan kemudahan akses.
                </P>
                <h3 class="font-bold text-2xl max-md:text-lg">Misi KALI</h3>
                <ul class="list-disc list-inside text-gray-700 space-y-2">
                    <li><strong class="text-biru">Transparansi:</strong> Menyediakan informasi yang jelas dan terperinci mengenai
                        penggunaan dana donasi.</li>
                    <li><strong class="text-biru">Keamanan:</strong> Memastikan bahwa setiap transaksi donasi dilakukan dengan aman dan
                        terlindungi.</li>
                    <li><strong class="text-biru">Kepedulian:</strong> Menginspirasi lebih banyak orang untuk terlibat dalam aksi sosial
                        dan memberikan kontribusi yang berarti.</li>
                </ul>

            </div>

        </div>
        <div class="border-2 rounded-sm border-white w-full"></div>
        <!-- team kami -->
        <div class="mt-20">
            <h2 class="text-center font-bold text-2xl text-white uppercase">Team Kami</h2>
            <div class="flex gap-6 flex-wrap max-md:flex-col justify-center">
                <div class="mt-20 bg-gradient-to-r from-cyan-500 to-biru border-2 p-2 w-3/12 max-md:w-full rounded-sm text-white text-center">
                    <img src="../../assets/images/agusmardi.png" alt="profil" class="rounded-sm w-full shadow-md">
                    <p class="font-semibold text-lg pt-2">Agus Mardianto</p>
                    <p>Front-End</p>
                </div>
                <div class="mt-20 bg-gradient-to-r from-cyan-500 to-biru border-2 p-2 w-3/12 max-md:w-full rounded-sm text-white text-center">
                    <img src="../../assets/images/mutiya.png" alt="profil" class="rounded-sm w-full shadow-md">
                    <p class="font-semibold text-lg pt-2">Mutiya Permatasari</p>
                    <p>Back-End</p>
                </div>
                <div class="mt-20 bg-gradient-to-r from-cyan-500 to-biru border-2 p-2 w-3/12 max-md:w-full rounded-sm text-white text-center">
                    <img src="../../assets/images/salman.png" alt="profil" class="rounded-sm w-full shadow-md">
                    <p class="font-semibold text-lg pt-2">Salman Asmandi</p>
                    <p>Front-End</p>
                </div>
            </div>
        </div>


    </div>
</template>

<script>

export default {

    name: 'AboutKali',


}
</script>

<style></style>