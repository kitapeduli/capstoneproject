//import vuex
import { createStore } from 'vuex'

//import module auth
import auth from './module/auth'

//import module donation
import donation from './module/donation'

//import module profile

import profile from './module/profile'
//create store vuex

//import module slider
import slider from './module/slider'

//import module category
import category from './module/category'

//import module campaign
import campaign from './module/campaign'

export default createStore({

    modules: {
        auth,       // <-- module auth register nich
        donation,   // <-- module donation
        profile,    // <-- module profile
        slider,     // <-- module slider
        category,   // <-- module category
        campaign,   // <-- module campaign
    }

})