//import axios
import axios from 'axios'

const Api = axios.create({
    // //set default endpoint API
    // baseURL: 'http://localhost:8000/api'

    // //set default endpoint API
    baseURL: 'https://kita-peduli.api-sim-pas2-bdg.cfd/api'
})

export default Api