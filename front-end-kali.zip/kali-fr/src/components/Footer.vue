<template>
    <div>
        <footer class="w-full mt-24  pt-4">
            <div class="w-2/3 m-auto text-center text-white font-medium leading-7 max-md:w-full max-md:p-4">
                <p class="pb-20 mt-20 text-lg max-md:text-sm max-sm:text-xs">“Satu rupiah penuh makna, menjadi berkah bagi yang menerima.Kebaikanmu
                    tak terhingga, pahala di sisi
                    Pencipta.”
                    <br>
                    “Kami ucapkan terima kasih yang tulus,Dari lubuk hati yang paling dalam.Semoga Allah membalas
                    kebaikanmu,Dengan kebahagiaan yang berlimpah.”</p>
            </div>
            <div class="bg-white pt-36 w-full py-6 flex justify-around gap-4 items-center h-full max-md:flex-col">
                <div class="deskripsi w-2/3  max-md:w-full max-md:p-4">
                    <div class="logo">
                        <img src="../assets/images/logo.png" alt="" class="w-36 max-md:w-24 mb-4">
                    </div>
                    <p class="leading-8 font-medium max-md:text-sm max-sm:text-xs">KALI | KITA PEDULI, merupakan platform website donasi yang dimana
                        untuk mengumpulkan pundi-pundi
                        donasi untuk di berikan kepada saudara-saudari kita yang terkena musibah, bencana, atau yang
                        dalam kesusahan.
                        kali berkomitmen akan memberikan dan menyalurkan bantuan yang ada secara nyata dan tanpa
                        rekayasa atau adanya penyalagunahan dana.</p>
                </div>
                <div class="tentang-link flex flex-col max-md:text-sm max-sm:text-xs max-md:w-full max-md:p-4">
                    <h3 class="font-bold">tentang</h3>
                    <router-link :to="{name:'about'}" class="block hover:text-biru">tentang kami</router-link>
                    <a href="" class="block hover:text-biru">partner</a>
                    <p>hubungi kami: </p>
                    <div class="flex justify-center gap-4 mt-4 text-lg max-md:text-sm">
                        <a href=""><i class="fa-brands fa-instagram text-biru"></i></a>
                        <a href=""><i class="fa-brands fa-x-twitter text-biru"></i></a>
                        <a href=""><i class="fa-brands fa-tiktok text-biru"></i></a>
                        <a href=""><i class="fa-brands fa-whatsapp text-biru"></i></a>
                    </div>

                </div>
            </div>
            <div class="bg-white p-4 text-sm font-medium">
                <p class="text-center max-md:text-sm max-sm:text-xs">© KALI | kita peduli, kita beraksi, kita memberi 2024</p>
            </div>
        </footer>

    </div>
</template>

<script>
export default {
    name: 'FooterComponent'
}
</script>

<style></style>