<template>
    <div class="relative box-border z-50">
      <!-- header -->
      <header
        class="border-b w-full box-border bg-white fixed top-0 left-0 right-0 max-md:h-16 max-md:flex max-md:items-center max-md:justify-between max-md:px-4">
  
        <button
          class="btn-menu hidden  max-md:block w-14 h-14 text-left text-2xl text-biru font-bold hover:scale-105 duration-75 z-50"
          id="btnMenu">☰</button>
        <router-link :to="{name:'home'}">
          <img src="../assets/images/icon-logo.png" alt="" class="w-10 rounded-sm hidden max-md:block" id="imgBar">
        </router-link>
        <div
          class="container h-16 bg-white m-auto flex justify-between items-center max-md:block max-md:p-4  max-md:duration-300 max-md:absolute max-md:left-0 max-md:bottom-96"
          id="appbar">
          <div class="logo max-md:flex max-md:justify-center max-md:mb-8">
            <router-link :to="{ name: 'home' }">
              <img src="../assets/images/logo.png" class="inline-block w-36 max-md:w-24">
            </router-link>
          </div>
          <nav class="flex max-md:bg-white max-md:p-4 max-md:rounded-sm max-md:shadow-sm">
            <ul class="flex items-center gap-7 max-md:gap-3 max-md:text-sm max-md:flex-col max-md:items-start">
              <li><router-link :to="{ name: 'home' }"
                  class="text-biru font-medium hover:text-blue-500 hover:border-b-2 py-2" id="beranda">Beranda</router-link>
              </li>
              <li><router-link :to="{ name: 'campaign.index' }"
                  class="text-biru font-medium hover:text-blue-500 hover:border-b-2 py-2" id="campaignLink">Campaign</router-link>
              </li>
              <li><router-link :to="{ name: 'dashboard' }"
                  class="text-biru font-medium hover:text-blue-500 hover:border-b-2 py-2 "
                  id="a">Akun</router-link>
              </li>
              <li><router-link :to="{ name: 'about' }"
                  class="text-biru font-medium hover:text-blue-500 hover:border-b-2 py-2 " id="tentangKali">Tentang
                Kali</router-link></li>
              <li><router-link :to="{ name: 'search' }"
                  class="text-biru font-medium hover:text-blue-500 hover:border-b-2 py-2 " id="cariDonasi">Cari Donasi <i class="fa-solid fa-magnifying-glass  ml-1"></i></router-link></li>
            </ul>
          </nav>
          <nav
            class="max-md:mt-3 mt-0 max-md:text-sm max-md:bg-biru max-md:w-full max-md:flex max-md:items-center max-md:h-10 max-md:rounded-sm ">
            <router-link :to="{ name: 'donation.index' }"
              class="bg-gradient-to-r from-cyan-500 to-biru relative py-2 px-3 text-white rounded-md hover:bg-white hover:text-gray-300 max-md:hover:bg-transparent max-md:font-medium duration-300 max-md:bg-gradient-to-r max-md:from-transparent max-md:to-transparent  "
              id="donasiSaya">Donasi
              Saya</router-link>
          </nav>
        </div>
      </header>
    </div>
  </template>
  
  <script>
  
  export default {
    name: 'HeaderComponent',
    mounted() {
      const btnMenu = document.querySelector('#btnMenu');
      const appBar = document.querySelector('#appbar');
      const imgBar = document.querySelector('#imgBar');
      const linkAkun = document.querySelector('#a');
      const linkDonasi = document.querySelector('#donasiSaya');
      const linkBeranda = document.querySelector('#beranda');  
      const linkCampaign = document.querySelector('#campaignLink');
      const linkKali = document.querySelector('#tentangKali');
      const linkCari =document.querySelector('#cariDonasi');
      // Set the initial state based on your design, hidden by default
  
      btnMenu.addEventListener('click', event => {
        _toggleDrawer(event, appBar);
      });
      linkAkun.addEventListener('click', event => {
        _closeDrawer(event, appBar);
      });
      linkDonasi.addEventListener('click', event => {
        _closeDrawer(event, appBar);
      });
      linkBeranda.addEventListener('click', event => {
        _closeDrawer(event, appBar);
      });
      linkCampaign.addEventListener('click', event => {
        _closeDrawer(event, appBar);
      });
      linkKali.addEventListener('click', event => {
        _closeDrawer(event, appBar);
      });
      linkCari.addEventListener('click', event => {
        _closeDrawer(event, appBar);
      });
  
      function _toggleDrawer(event, appBar) {
        event.stopPropagation();
        imgBar.classList.toggle('hilang');
        appBar.classList.toggle('buka');
      }
  
      function _closeDrawer(event, appBar) {
        event.stopPropagation();
        imgBar.classList.toggle('tutup');
        appBar.classList.remove('buka');
        imgBar.classList.remove('hilang');
      }
    }
  };
  </script>
  
  <style scoped>
  .buka {
    bottom: 0;
  }
  
  .hilang {
    display: none;
  }
  
  .tutup {
    top: -1000px;
  }
  </style>
  