<template>
    <div class="box-border lg:py-10">
        <div class="text-center text-2xl mt-4 font-bold uppercase text-white max-md:text-lg max-sm:text-sm">pilih kategori</div>
        <div v-if="categories.length > 0" class="my-10 w-4/5 flex m-auto justify-center flex-wrap">
            <!-- con card -->
            <div class="flex justify-center gap-4 max-lg:gap-2 w-full flex-wrap">
                <!-- card -->
                <div v-for="category in categories" :key="category.id" class="w-1/5 max-sm:w-28 max-lg:w-36 max-lg:h-40 max-md:h-32 h-full bg-white p-2 rounded-sm box-border text-biru hover:bg-gradient-to-r from-cyan-500 to-biru duration-300 hover:border hover:scale-105 hover:text-white font-medium text-center group flex justify-center items-center lg:text-lg max-md:text-sm max-sm:text-xs">
                    <router-link :to="{name: 'category.show', params:{slug: category.slug}}" class="max-sm:text-sm">
                        <div>
                            <img :src="category.image" class="mb-2 rounded-sm shadow-lg border border-gray-50 p-1 box-border  duration-300 h-24 w-24 max-lg:w-20 max-lg:h-20 max-md:w-16 max-md:h-16 max-sm:w-12 max-sm:h-12 m-auto block group-hover:bg-white">
                        </div>
                        {{ category.name.toUpperCase() }}
                    </router-link>
                </div>
                <!-- card lainnya -->
                <div class="bg-white w-1/5 max-lg:w-36 max-md:h-32 max-sm:w-28 flex text-biru justify-center items-center text-center p-2 rounded-sm hover:bg-gray-200 duration-300">
                    <router-link :to="{name: 'category.index'}" class="max-sm:text-sm">
                        <div>
                            
                            <img src="../assets/images/lainnya.png" width="40" class="inline-block mb-2">
                        </div>
                        LAINNYA
                    </router-link>
                </div>
            </div>
        </div>
        <div v-else>
            <div class="mt-5 grid grid-cols-4  gap-4 md:gap-4 text-center items-center">
                <div v-for="index in 4" :key="index" class="sm:col-span-2 md:col-span-2 lg:col-span-2 bg-white rounded-md shadow-md text-center text-xs">
                    <ContentLoader/>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    //hook vue
    import { computed, onMounted  } from 'vue'
    
    //vuex
    import { useStore } from 'vuex'
    
    //vue content loader
    import { ContentLoader } from 'vue-content-loader'

    export default {

        name: 'CategoryHomeComponent',

        components: {
            ContentLoader   // <-- register content loader
        },

        setup() {

            //store vuex
            const store = useStore()

            //onMounted akan menjalankan action "getCategoryHome" di module "category"
            onMounted(() => {
                store.dispatch('category/getCategoryHome')
            })

            //digunakan untuk get data state "categories" di module "category" 
            const categories = computed(() => {
                return store.state.category.categories
            })

            return {
                categories  // <-- categories
            }

        }

    }
</script>

<style>

</style>