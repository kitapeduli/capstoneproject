/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{vue,js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'biru': '#004AAD',
        'heroc': '#004bad54'
      },
      backgroundImage: {
        'heroo': "url('hero.png')",
      }
      
    },
  },
  plugins: [],
}